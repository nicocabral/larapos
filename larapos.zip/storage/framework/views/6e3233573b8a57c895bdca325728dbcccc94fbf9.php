<!DOCTYPE html>
<html lang="en">
<head>
	<title>Quick Book Point of Sale</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/logohead.png')); ?>"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/login/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/login/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/login/vendor/animate/animate.css')); ?>">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/login/vendor/css-hamburgers/hamburgers.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/login/vendor/select2/select2.min.css')); ?>">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/login/css/util.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/login/css/main.css')); ?>">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<div class="login100-pic js-tilt" data-tilt>
					<img src="<?php echo e(asset('assets/login/images/img-01.png')); ?>" alt="IMG">
				</div>

				<form  id="loginForm" action="<?php echo e(route('api.login')); ?>" method="post">
					 <?php echo csrf_field(); ?>
					<span class="login100-form-title">
						<i class="fa fa-life-ring" aria-hidden="true"></i> Forgot password
					</span>
					<?php if(Session::has('error')): ?>
						<div class="alert alert-danger alert-dismissible fade show" role="alert">
						  <span><i class="fa fa-exclamation-circle" aria-hidden="true"></i> <?php echo e(Session::get("error")); ?></span>
						  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
						    <span aria-hidden="true">&times;</span>
						  </button>
						</div>
					<?php endif; ?>
					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="username" placeholder="Username">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<input class="input100" type="password" name="password" placeholder="New password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn btnLogin" data-loading-text="<i class='fas fa-circle-notch fa-spin'></i> saving...">
							Save
						</button>
					</div>

					<div class="text-center p-t-12">
						
						<a class="txt2" href="<?php echo e(route('index')); ?>">
							Login
						</a>
					</div>

					<div class="text-center p-t-136">
						<a class="txt2" href="#">
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
	
	

	
<!--===============================================================================================-->	
	<script src="<?php echo e(asset('assets/login/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('assets/login/vendor/bootstrap/js/popper.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/login/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('assets/login/vendor/select2/select2.min.js')); ?>"></script>
<!--===============================================================================================-->
	<script src="<?php echo e(asset('assets/login/vendor/tilt/tilt.jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/page/page.js')); ?>"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
		$(document).on('click', '.btnLogin', function(){
			$(this).buttonLoader('loading');
			$('#loginForm').submit()
		});
	</script>
<!--===============================================================================================-->


</body>
</html>