<nav class="navbar navbar-expand-lg navbar-dark bg-primary nav-gradient">
  <a class="navbar-brand " href="/ses/portal/views/"  >
    <img src="<?php echo e(asset('assets/img/brand.png')); ?>" alt="" class="img-fluid">
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('index')); ?>">Quick Book Point of Sale <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item " data-href="products">
        <a class="nav-link" href="<?php echo e(route('products')); ?>" ><img src="<?php echo e(asset('assets/img/products.png')); ?>" alt="Products" class="img-fluid"> Products</a>
      </li>
      <li class="nav-item " data-href="categories">
        <a class="nav-link" href="<?php echo e(route('categories')); ?>"><img src="<?php echo e(asset('assets/img/cat.png')); ?>" alt="Category" class="img-fluid"> Category</a>
      </li>
      <li class="nav-item " data-href="pos">
        <a class="nav-link" href="<?php echo e(route('pos')); ?>"><img src="<?php echo e(asset('assets/img/sales.png')); ?>" alt="Sales" class="img-fluid"> Point of Sale</a>
      </li>
      <li class="nav-item " data-href="users">
        <a class="nav-link" href="<?php echo e(route('users')); ?>"><img src="<?php echo e(asset('assets/img/users.png')); ?>" alt="Users" class="img-fluid"> Users</a>
      </li>
    </ul>
    
    <?php if(Auth::check()): ?>
    <a href="javascript:void(0);" class="mr-3 myaccount" style="color:#FFFF !important;"><img src="<?php echo e(asset('assets/img/user.png')); ?>" alt="User" class="img-fluid">  <?php echo Auth::user()->first_name. ', '. Auth::user()->last_name; ?></a>
    <a href="javascript:void(0);" class="btnLogout" style="color:#FFFF !important;"><img src="<?php echo e(asset('assets/img/exit.png')); ?>" alt="Logout" class="img-fluid"> Logout</a>
    <?php endif; ?>   
  </div>
</nav>